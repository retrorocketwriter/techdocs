const yaml = require('js-yaml');
const fs = require('fs');
try {
    const config = yaml.safeLoad(fs.readFileSync('test.yaml', 'utf8'));

// JSON OUTPUT
//    console.log(config);

// INFO
    console.log('INFO');    
    
    console.log("     swagger: " + config.swagger);
    console.log("     title: " + config.info.title);
    console.log("     description: " + config.info.description);
    console.log("     terms: " + config.info.termsOfService);
    console.log (" ");

// PATHS 
    console.log('PATHS');
    
    Object.keys(config.paths).forEach(function(pathK, pathV){
        //console.log(pathK); // method path

        //METHODS
        Object.keys(config.paths[pathK]).forEach(function(methodK, methodV){
            console.log(methodK + ": " + pathK); // method (GET, PUT, DELETE)
            
            //METHOD VALUES
            Object.keys(config.paths[pathK][methodK]).forEach(function(valueK, valueV){
                if (typeof(config['paths'][pathK][methodK][valueK]) == 'object') {
                    
                   switch (valueK) {
                       case "tags":
                       case "produces" :
                           Object.keys(config.paths[pathK][methodK][valueK]).forEach(function(detailK, detailV){ 
                                console.log('          ' + valueK + ': '  + config['paths'][pathK][methodK][valueK][detailK] );                    
                           });
                           break;
                           
                       case "parameters" :
                           console.log('          ' + valueK + ':');
                           var paramObject = config.paths[pathK][methodK][valueK];
                           for (var paramKey in paramObject) {
                               console.log('              in: ' + paramObject[paramKey]["in"]);
                               console.log('              name: ' + paramObject[paramKey]["name"]);
                               console.log('              required: ' + paramObject[paramKey]["required"]); 
                               console.log('              type: ' + paramObject[paramKey]["type"]);   
                               console.log('              desc: ' + paramObject[paramKey]["description"]);
                               if (typeof(paramObject[paramKey]["schema"]) == 'object') {
                                   console.log('              schema: ');
                                   Object.keys(paramObject[paramKey]["schema"]).forEach(function(schemaK,schemaV) {
                                    console.log('                   ' + schemaK + ': ' + paramObject[paramKey]["schema"][schemaK]);           
                                   });
                               }
                           }
                           break;
                           
                       case "security" : 
                           console.log('          ' + valueK + ':');
                           Object.keys(config.paths[pathK][methodK][valueK]).forEach(function(securityK, securityV){ 
                               if (typeof(config['paths'][pathK][methodK][valueK][securityK]) == "object") {
                                   var securityObject = config['paths'][pathK][methodK][valueK][securityK];
                                   for (var secKey in securityObject) {
                                     console.log ('               ' + secKey + ': ' + securityObject[secKey]); 
                                   }
                               }
                           });
                            
                           break;
                           
                       case "responses" :
                           console.log('          ' + valueK + ':');
                           Object.keys(config.paths[pathK][methodK][valueK]).forEach(function(responseK, responseV) { 
                               console.log('              ' + responseK + ':');
                                if (typeof(config['paths'][pathK][methodK][valueK][responseK]) == "object") {
                                   var responseObject = config['paths'][pathK][methodK][valueK][responseK];
                                   for (var respKey in responseObject) {
                                       if (typeof(responseObject[respKey]) == "object") {
                                           var schemaObject = responseObject[respKey];
                                           for (var schemaKey in schemaObject) {
                                             console.log ('               ' + schemaKey + ': ' + schemaObject[schemaKey]); 
                                           }
                                       }
                                       else {
                                            console.log ('               ' + respKey + ': ' + responseObject[respKey]);                                 
                                       }
                                   }
                               }           
                           });
                           break;
                           
                       default:
                           break;
                   }
                    
                }
                else {
                    console.log('          ' + valueK + ': '  + config['paths'][pathK][methodK][valueK] );                    
                }
                                    
            });
            
        });
    
        console.log(' ');
        
    });    
    
    console.log('SECURITY');
    
    console.log('SCHEMA OBJECTS');
    
    Object.keys(config.definitions).forEach(function(defK, defV) {
        console.log(defK); // objects
        
        Object.keys(config.definitions[defK]).forEach(function(propK, propV){
            console.log('     ' + propK + ":"); // object properties
            
            if (typeof(config.definitions[defK][propK]) == 'object') {
            
                Object.keys(config.definitions[defK][propK]).forEach(function(valK, valV){
                    
                    if (typeof(config.definitions[defK][propK][valK]) == 'object') { 
                        console.log('          ' + valK + ": ")
                        var propObject = config.definitions[defK][propK][valK];
                        for (propKey in propObject)
                        {
                            console.log('               ' + propObject[propKey]);        
                        }
                    }
                        
                    else {
                        console.log('          ' + valK + ": " + config.definitions[defK][propK][valK]);        
                    }

                });                    
            }
            else {
                 console.log('          ' + config['definitions'][defK][propK] );                    

            }
            
        });
        
        console.log (" ");
        console.log (" -- JSON Object ");
        // parse the schema back into JSON
        var indentedJSON = JSON.stringify(config.definitions[defK], null, 4);
        console.log (indentedJSON);
        console.log (" ");
    
    });        
    

} catch (e) {
    console.log(e);
}




